import React from 'react';
import Overalls from './peach/Overalls';

const App = () => {
    return (
        <div>
            <Overalls/>
        </div>
    );
};

export default App;